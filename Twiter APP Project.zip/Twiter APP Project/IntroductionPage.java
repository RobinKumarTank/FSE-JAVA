public class IntroductionPage {

    public static void main(String args []){

        System.out.println("Introduction menu for guest user!!");

        String Register;
        System.out.println("Register");
        String Login;
        System.out.println("Login");
        String Forgot_Password;
        System.out.println("Forgot Password");

    }
}
