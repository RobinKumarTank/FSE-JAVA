public class MenuForLoginUser {

    public static void main(String args []){

        System.out.println("Menu for Login user !!");
        System.out.println("Post a tweet");
        System.out.println("View My Tweets");
        System.out.println("View all Tweets");
        System.out.println("View all users");
        System.out.println("Reset Password");
        System.out.println("Logout");

    }
}
